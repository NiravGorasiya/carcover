const methods = require("./crudController");
module.exports = methods.travePlan("Travelplan");
