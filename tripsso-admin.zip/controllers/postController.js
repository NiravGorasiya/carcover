const methods = require("./crudController");
module.exports = methods.post("Feeds");
