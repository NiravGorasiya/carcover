const methods = require("./crudController");
module.exports = methods.article("Article");
