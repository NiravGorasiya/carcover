exports.GOOGLE_CLOUD_SERVICE = {
        key_path: "./config/double-willow-332106-618518fd794b.json",
        bucket: "travelfish-storage-bucket-staging",
        projectId: "double-willow-332106",
        cdn_host: "https://tfcdn.keylogicinfotech.com"
}